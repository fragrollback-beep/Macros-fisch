#Requires AutoHotkey v2.0

global VERSION_CHECK_COOLDOWN_MS := 60000
global _LastVersionCheckAt := 0

CheckRobloxVersionMismatch(pid) {
    global _LastVersionCheckAt, VERSION_CHECK_COOLDOWN_MS

    if (!pid)
        return

    if (_LastVersionCheckAt && (A_TickCount - _LastVersionCheckAt) < VERSION_CHECK_COOLDOWN_MS)
        return

    _LastVersionCheckAt := A_TickCount

    try {
        runningHash := GetRunningRobloxVersionHash(pid)
        latestHash := GetLatestRobloxVersionHash()

        if (runningHash != latestHash)
            MsgBox("Version mismatch detected.`n`nRunning: " runningHash "`nLatest:  " latestHash, "Version Warning")
    } catch as err {
        MsgBox("Version check failed: " err.Message "`n`nProceeding with re-attach.", "Version Warning")
    }
}

StartMacro() {
    global Macro

    if (Macro.cycleEnabled) {
        Macro.cycleEnabled := false
        if (Macro.phase = "APPRAISE")
            StopAppraiseCycle("OFF")
        else
            StopMacroCycle("OFF")
        return
    }

    if !EnsureRobloxReady(true, true)
        return

    UpdateRobloxUiState()

    if (IsAutoAppraiseRuntimeEnabled()) {
        if (Macro.phase = "OFF" || Macro.phase = "DONE" || Macro.phase = "FAILED")
            StartAppraiseCycle()
        return
    }

    if (!IsAnythingEquipped()) {
        SendInput("{vk54}")  ; vk54 = T key — layout-independent
        Sleep(200)
    }

    Macro.cycleEnabled := true

    if (Macro.phase = "OFF" || Macro.phase = "DONE" || Macro.phase = "FAILED")
        StartMacroCycle()
}

FixRoblox() {
    pid := GetRobloxPID()
    if (!pid) {
        ResetRobloxAttachmentState()
        ClearMacroPhaseCache()
        UpdateRobloxUiState()
        MsgBox("Roblox not found.")
        return
    }

    ClearMacroPhaseCache()

    CheckRobloxVersionMismatch(pid)

    try {
        AttachToRoblox(pid)
        UpdateRobloxUiState()
        MsgBox("Roblox attachment refreshed.")
    } catch as err {
        UpdateRobloxUiState()
        MsgBox(err.Message, "Roblox Attachment")
    }
}

ReloadMacro() {
    Reload()
}

StopAppraisingHotkey() {
    global Macro
    if (Macro.phase = "APPRAISE" && Macro.cycleEnabled)
        StopAppraiseCycle("OFF", "Stopped by hotkey.")
}

class HotkeyManager {
    static activeHotkeys := Map()

    static RegisterAll(settings) {
        hotkeys := settings["hotkeys"]
        this.Register(hotkeys["start_macro"], (*) => StartMacro())
        if (hotkeys.Has("stop_appraise") && hotkeys["stop_appraise"] != "")
            this.Register(hotkeys["stop_appraise"], (*) => StopAppraisingHotkey())
        this.Register(hotkeys["fix_roblox"], (*) => FixRoblox())
        this.Register(hotkeys["reload"], (*) => ReloadMacro())
    }

    static Register(key, callback) {
        if (key = "")
            return

        Hotkey(key, callback)
        this.activeHotkeys[key] := callback
    }

    static ChangeHotkey(oldKey, newKey, callback) {
        if (oldKey = newKey)
            return

        if (oldKey != "" && this.activeHotkeys.Has(oldKey)) {
            Hotkey(oldKey, "Off")
            this.activeHotkeys.Delete(oldKey)
        }

        this.Register(newKey, callback)
    }
}
