#Requires AutoHotkey v2.0

ClearMacroPhaseCache() {
    global Macro
    Macro.reelGuiAddr := 0
    Macro.reelBarAddr := 0
    Macro.fishAddr := 0
    Macro.playerbarAddr := 0
    Macro.progressBarAddr := 0
    Macro.powerBarAddr := 0
    Macro.appraiseSubvaluesAddr := 0
    Macro.appraiseState := "IDLE"
    Macro.appraiseLastClickAt := 0
    Macro.appraiseWaitStartedAt := 0
    Macro.appraiseStartCoins := ""
    Macro.appraiseEndCoins := ""
    Macro.appraiseLastError := ""
}

CreateFishingMacro() {
    return {
        phase: "OFF",
        powerPercent: "",
        progressPercent: "",
        isHolding: false,
        castThreshold: 96.0,
        castWaitTimeoutMs: 15000,
        fishingEndGraceMs: 100,
        castStartedAt: 0,
        castReleasedAt: 0,
        castBarSeen: false,
        fishingLostAt: 0,
        completionReached: false,
        outcomeResolved: false,
        fishCaughtCount: 0,
        fishLostCount: 0,
        castTimeoutCount: 0,
        totemPopCount: 0,
        shakingIntervalMs: 25,
        lastShakedAt: 0,
        lastActionAt: 0,
        ActivatedUiNav: false,
        cycleEnabled: false,
        totemState: "IDLE",
        totemRetryCount: 0,
        totemWaitStartedAt: 0,
        lastTotemSuccessAt: 0,
        lastTotemAttemptAt: 0,
        totemPending: false,
        totemBlockedUntilCatchEnd: false,
        totemNightCovered: false,
        totemNeedsRodReequip: false,
        totemNeedsSettleDelay: false,
        reelGuiAddr: 0,
        reelBarAddr: 0,
        fishAddr: 0,
        playerbarAddr: 0,
        progressBarAddr: 0,
        powerBarAddr: 0,
        appraiseSubvaluesAddr: 0,
        appraiseLastClickAt: 0,
        appraiseWaitStartedAt: 0,
        appraiseStartCoins: "",
        appraiseEndCoins: "",
        appraiseState: "IDLE",
        appraiseLastError: ""
    }
}

ResolveCastThreshold() {
    global MAIN
    switch MAIN["cast_mode"] {
        case "short":  return 28.0
        case "custom": return Max(1.0, Min(100.0, MAIN["cast_power_custom"] + 0.0))
        default:       return 96.0
    }
}

InitializeCastCycle() {
    global Macro, MAIN

    if (!Macro.ActivatedUiNav) {
        SendInput("{vkDC}")  ; vkDC = OEM_5 = backslash — layout-independent
        Macro.ActivatedUiNav := true
        Sleep(50)
    }

    Macro.powerPercent := ""
    Macro.progressPercent := ""
    Macro.castStartedAt := A_TickCount
    Macro.castReleasedAt := 0
    Macro.castBarSeen := false
    Macro.fishingLostAt := 0
    Macro.completionReached := false
    Macro.outcomeResolved := false
    Macro.lastShakedAt := 0
    Macro.lastActionAt := 0
    Macro.powerBarAddr := 0
    Macro.castThreshold := ResolveCastThreshold()
    Macro.castWaitTimeoutMs := Max(GetMinCastTimeoutMs(), MAIN["cast_timeout_ms"] + 0)
    Macro.fishingEndGraceMs := 100
    Macro.shakingIntervalMs := MAIN["shake_interval_ms"]
    Macro.phase := "CASTING"

    UpdateMacroStatus("CASTING", "---", "---")
}

MacroLoop() {
    global Macro

    if (Macro.phase != "APPRAISE" && UpdateAutoTotem()) {
        UpdateMacroStatus(GetMacroDisplayStatus(), "---", "---")
        return
    }

    switch Macro.phase {
        case "CASTING":
            UpdateCastingPhase()
        case "CASTED":
            UpdateCastedPhase()
        case "SHAKE":
            UpdateShakePhase()
        case "FISHING":
            UpdateFishingPhase()
        case "TRANQUILITY":
            UpdateTranquilityPhase()
        case "DONE":
            if (Macro.cycleEnabled)
                StartMacroCycle()
            else
                StopMacroCycle("OFF")
        case "APPRAISE":
            UpdateAppraisePhase()
        case "OFF":
    }

    UpdateMacroStatus(
        GetMacroDisplayStatus(),
        (Macro.powerPercent = "" ? "---" : Macro.powerPercent "%"),
        (Macro.progressPercent = "" ? "---" : Macro.progressPercent "%")
    )

    if (Macro.phase != "OFF")
        SendSummaryWebhook()
}

StartMacroCycle() {
    global Macro, Controller, ROD, WebhookSession

    if (Macro.phase = "OFF") {
        Macro.totemNightCovered := false
        Macro.totemPending := false
        Macro.totemBlockedUntilCatchEnd := false

        if (WebhookSession.startedAt = 0) {
            WebhookSession.startedAt := A_TickCount
            WebhookSession.lastSummaryAt := A_TickCount
        }
    }

    if (IsTranquilityRodText(ROD))
        Controller := TranquilityController()
    else if (IsPinionRodText(ROD))
        Controller := PinionController()
    else
        Controller := FishingController()
    ReleaseMouse()
    Controller.Reset()
    InitializeCastCycle()
}

StopMacroCycle(nextPhase := "OFF") {
    global Macro, Controller

    finalProgress := Macro.progressPercent

    ReleaseMouse()
    Controller.Reset()

    Macro.powerPercent := ""
    Macro.castStartedAt := 0
    Macro.castReleasedAt := 0
    Macro.castBarSeen := false
    Macro.progressPercent := ""
    Macro.fishingLostAt := 0
    Macro.completionReached := false
    Macro.outcomeResolved := false
    Macro.lastShakedAt := 0
    Macro.lastActionAt := 0
    Macro.reelGuiAddr := 0
    Macro.reelBarAddr := 0
    Macro.fishAddr := 0
    Macro.playerbarAddr := 0
    Macro.progressBarAddr := 0
    if (nextPhase = "OFF")
        ClearAppraiseRuntimeCache()
    Macro.phase := nextPhase

    if (nextPhase = "DONE")
        Macro.totemBlockedUntilCatchEnd := false
    else if (nextPhase = "OFF") {
        if (Macro.totemState != "IDLE" && Macro.totemNeedsRodReequip)
            SelectHotbarSlot("1")
        ResetAutoTotemControl()
        Macro.totemNightCovered := false
    }

    UpdateMacroStatus(
        GetMacroDisplayStatus(),
        "---",
        (nextPhase = "DONE" && finalProgress != "" ? finalProgress "%" : "---")
    )
}

GetMacroDisplayStatus() {
    global Macro
    if (Macro.phase = "APPRAISE")
        return "APPRAISE " Macro.appraiseState
    return (Macro.totemState != "IDLE") ? Macro.totemState : Macro.phase
}

ResetAutoTotemControl() {
    global Macro

    Macro.totemState := "IDLE"
    Macro.totemRetryCount := 0
    Macro.totemWaitStartedAt := 0
    Macro.totemPending := false
    Macro.totemBlockedUntilCatchEnd := false
    Macro.totemNeedsRodReequip := false
    Macro.totemNeedsSettleDelay := false
}

IsAutoTotemRuntimeEnabled() {
    global MAIN
    return MAIN["auto_totem_enabled"] && (MAIN["auto_totem_name"] = "Aurora Totem")
}

GetAutoTotemIntervalMs() {
    global MAIN
    return Max(1, MAIN["auto_totem_interval_sec"] + 0) * 1000
}

GetCycleStartDelayMs() {
    global MAIN
    return Max(0, MAIN["pre_cast_delay_ms"] + 0)
}

IsAutoTotemBoundary() {
    global Macro
    return (Macro.phase = "CASTING" && !Macro.isHolding && !Macro.castBarSeen)
}

IsAutoTotemDue() {
    global MAIN, Macro

    if !IsAutoTotemRuntimeEnabled()
        return false

    if (MAIN["auto_totem_mode"] = "interval") {
        referenceAt := Macro.lastTotemSuccessAt
        if (Macro.lastTotemAttemptAt > referenceAt)
            referenceAt := Macro.lastTotemAttemptAt

        return (!referenceAt || (A_TickCount - referenceAt) >= GetAutoTotemIntervalMs())
    }

    if (Macro.totemNightCovered) {
        cycleText := StrLower(GetWorldStatusText("4_cycle"))
        if (cycleText = "" || InStr(cycleText, "night"))
            return false

        Macro.totemNightCovered := false
    }

    return true
}

UpdateAutoTotem() {
    global Macro, Controller

    if !IsAutoTotemRuntimeEnabled() {
        if (Macro.totemState != "IDLE" || Macro.totemPending || Macro.totemBlockedUntilCatchEnd) {
            ReleaseMouse()
            Controller.Reset()
            if (Macro.totemState != "IDLE" && Macro.totemNeedsRodReequip)
                SelectHotbarSlot("1")
            ResetAutoTotemControl()
        }
        return false
    }

    if (Macro.totemState != "IDLE") {
        Macro.powerPercent := ""
        Macro.progressPercent := ""
        ReleaseMouse()
        Controller.Reset()
        UpdateAutoTotemState()
        return true
    }

    if !Macro.cycleEnabled
        return false

    if (Macro.totemPending && IsAutoTotemBoundary()) {
        BeginAutoTotemWorkflow()
        return true
    }

    if (Macro.totemBlockedUntilCatchEnd)
        return false

    if (IsAutoTotemDue()) {
        if (IsAutoTotemBoundary()) {
            BeginAutoTotemWorkflow()
            return true
        }

        if !Macro.totemPending {
            if (Macro.phase != "OFF")
                Macro.totemNeedsSettleDelay := true
        }

        Macro.totemPending := true
    }

    return false
}

BeginAutoTotemWorkflow() {
    global Macro, Controller

    Macro.powerPercent := ""
    Macro.progressPercent := ""
    Macro.totemPending := false
    Macro.totemRetryCount := 0
    Macro.totemWaitStartedAt := 0
    Macro.lastTotemAttemptAt := A_TickCount
    Macro.totemNeedsRodReequip := false

    ReleaseMouse()
    Controller.Reset()
    if (Macro.totemNeedsSettleDelay) {
        Macro.totemState := "TOTEM_SETTLE"
        Macro.totemWaitStartedAt := A_TickCount
        return
    }

    RunAutoTotemWorkflowStep()
}

RunAutoTotemWorkflowStep() {
    global Macro

    if (IsAuroraActive()) {
        CompleteAutoTotemWorkflow(true)
        return
    }

    if (IsNightCycle()) {
        if (!TryUseAutoTotemItem("Aurora Totem")) {
            CompleteAutoTotemWorkflow(false)
            return
        }

        Macro.totemState := "TOTEM_WAIT_AURORA"
        Macro.totemWaitStartedAt := A_TickCount
        return
    }

    if (!TryUseAutoTotemItem("Sundial Totem")) {
        CompleteAutoTotemWorkflow(false)
        return
    }

    Macro.totemState := "TOTEM_WAIT_NIGHT"
    Macro.totemWaitStartedAt := A_TickCount
}

UpdateAutoTotemState() {
    global Macro

    if (IsAuroraActive()) {
        CompleteAutoTotemWorkflow(true)
        return
    }

    switch Macro.totemState {
        case "TOTEM_SETTLE":
            if ((A_TickCount - Macro.totemWaitStartedAt) < GetCycleStartDelayMs())
                return

            Macro.totemNeedsSettleDelay := false
            Macro.totemWaitStartedAt := 0
            RunAutoTotemWorkflowStep()
            return

        case "TOTEM_WAIT_NIGHT":
            if (IsNightCycle()) {
                Macro.totemRetryCount := 0

                if (!TryUseAutoTotemItem("Aurora Totem")) {
                    CompleteAutoTotemWorkflow(false)
                    return
                }

                Macro.totemState := "TOTEM_WAIT_AURORA"
                Macro.totemWaitStartedAt := A_TickCount
                return
            }

            if ((A_TickCount - Macro.totemWaitStartedAt) < GetAutoTotemWaitMs())
                return

            if (Macro.totemRetryCount >= 1) {
                CompleteAutoTotemWorkflow(false)
                return
            }

            if (!TryUseAutoTotemItem("Sundial Totem")) {
                CompleteAutoTotemWorkflow(false)
                return
            }

            Macro.totemRetryCount += 1
            Macro.totemWaitStartedAt := A_TickCount

        case "TOTEM_WAIT_AURORA":
            if ((A_TickCount - Macro.totemWaitStartedAt) < GetAutoTotemWaitMs())
                return

            if (Macro.totemRetryCount >= 1) {
                CompleteAutoTotemWorkflow(false)
                return
            }

            if (!TryUseAutoTotemItem("Aurora Totem")) {
                CompleteAutoTotemWorkflow(false)
                return
            }

            Macro.totemRetryCount += 1
            Macro.totemWaitStartedAt := A_TickCount
    }
}

TryUseAutoTotemItem(itemName) {
    global Macro

    if !TryUseHotbarItem(itemName)
        return false

    Macro.totemNeedsRodReequip := true
    return true
}

CompleteAutoTotemWorkflow(success := false) {
    global Macro, MAIN

    needsRodReequip := Macro.totemNeedsRodReequip

    if (success) {
        Macro.lastTotemSuccessAt := A_TickCount
        Macro.totemNightCovered := true
        Macro.totemPopCount += 1
    } else if (MAIN["webhook_alert_totem_failed"]) {
        SendInstantAlert("Auto Totem Failed", "The auto totem workflow could not complete successfully.")
    }

    ResetAutoTotemControl()

    if (needsRodReequip)
        EnsureRodEquipped()

    if (!success && MAIN["auto_totem_mode"] = "expire")
        Macro.totemBlockedUntilCatchEnd := true

    if (Macro.cycleEnabled && Macro.phase = "CASTING") {
        InitializeCastCycle()
    }
}

UpdateCastingPhase() {
    global Macro, MAIN

    Macro.progressPercent := ""

    cycleStartDelayMs := GetCycleStartDelayMs()
    if (cycleStartDelayMs > 0 && (A_TickCount - Macro.castStartedAt) < cycleStartDelayMs)
        return

    HoldMouse()

    if (!Macro.castStartedAt)
        Macro.castStartedAt := A_TickCount

    resolved := ResolvePowerBarPath()
    if (!resolved.bar) {
        Macro.powerPercent := "---"

        if ((A_TickCount - Macro.castStartedAt) >= Macro.castWaitTimeoutMs) {
            Macro.castTimeoutCount += 1
            MAIN["cast_on_timeout"] ? StartMacroCycle() : StopMacroCycle("OFF")
        }

        return
    }

    Macro.castBarSeen := true

    percent := ReadPowerBarPercent(resolved.bar)
    Macro.powerPercent := Format("{:.1f}", percent)

    if (percent >= Macro.castThreshold) {
        ReleaseMouse()
        Macro.castReleasedAt := A_TickCount
        Macro.phase := "CASTED"
        return
    }

    if ((A_TickCount - Macro.castStartedAt) >= Macro.castWaitTimeoutMs) {
        Macro.castTimeoutCount += 1
        MAIN["cast_on_timeout"] ? StartMacroCycle() : StopMacroCycle("OFF")
    }
}

UpdateCastedPhase() {
    global Macro, MAIN

    Macro.powerPercent := ""
    Macro.progressPercent := ""
    ReleaseMouse()

    if (!Macro.castReleasedAt)
        Macro.castReleasedAt := A_TickCount

    if ((A_TickCount - Macro.castReleasedAt) < MAIN["post_cast_delay_ms"])
        return

    Macro.lastShakedAt := 0
    Macro.phase := "SHAKE"
}

UpdateShakePhase() {
    global Macro, ROD

    Macro.powerPercent := ""
    Macro.progressPercent := ""
    ReleaseMouse()

    if (IsTranquilityRodText(ROD) && GetTranquilityLaneContainer()) {
        Macro.lastShakedAt := 0
        Macro.fishingLostAt := 0
        Macro.phase := "TRANQUILITY"
        return
    }

    if (HasActiveFishingContext()) {
        Macro.lastShakedAt := 0
        Macro.fishingLostAt := 0
        Macro.phase := "FISHING"
        return
    }

    if (!Macro.lastShakedAt || (A_TickCount - Macro.lastShakedAt) >= Macro.shakingIntervalMs) {
        SendInput("{Enter}")
        Macro.lastShakedAt := A_TickCount
    }

    shakeRef := Macro.castReleasedAt ? Macro.castReleasedAt : Macro.castStartedAt
    if (shakeRef && (A_TickCount - shakeRef) >= Macro.castWaitTimeoutMs)
        StartMacroCycle()
}

UpdateFishingPhase() {
    global Macro, Controller, MAIN

    Macro.powerPercent := ""

    reelGuiVisible := IsReelGuiVisible()
    ctx := reelGuiVisible ? GetReelBarContext() : 0

    progress := GetFishingCompletionPercent()
    Macro.progressPercent := (progress = "" ? "" : Round(progress))

    if (progress != "" && progress >= (MAIN["completion_threshold"] + 0.0))
        Macro.completionReached := true

    if (Macro.completionReached) {
        ReleaseMouse(true)
        Controller.Reset()

        if (reelGuiVisible) {
            Macro.fishingLostAt := 0
            return
        }

        ctx := 0
    }

    if (ctx) {
        Macro.fishingLostAt := 0

        if (HasActiveFishingContext(ctx))
            Controller.Update(ctx)
        else
            ReleaseMouse()
        return
    }

    ReleaseMouse()
    Controller.Reset()

    if (!Macro.fishingLostAt)
        Macro.fishingLostAt := A_TickCount

    if ((A_TickCount - Macro.fishingLostAt) >= Macro.fishingEndGraceMs) {
        if (!Macro.outcomeResolved) {
            Macro.outcomeResolved := true
            if (Macro.completionReached)
                Macro.fishCaughtCount += 1
            else
                Macro.fishLostCount += 1
        }
        StopMacroCycle("DONE")
    }
}

UpdateTranquilityPhase() {
    global Macro, Controller, MAIN

    Macro.powerPercent := ""

    root := GetTranquilityRoot()
    progress := ReadTranquilityProgressPercent(root)
    Macro.progressPercent := (progress = "" ? "" : Round(progress))

    if (progress != "" && progress >= (MAIN["completion_threshold"] + 0.0))
        Macro.completionReached := true

    container := root ? GetTranquilityLaneContainer(root) : 0

    if (container) {
        Macro.fishingLostAt := 0
        Controller.Update()
        return
    }

    if (!Macro.fishingLostAt)
        Macro.fishingLostAt := A_TickCount

    if ((A_TickCount - Macro.fishingLostAt) >= Macro.fishingEndGraceMs) {
        if (!Macro.outcomeResolved) {
            Macro.outcomeResolved := true
            if (Macro.completionReached)
                Macro.fishCaughtCount += 1
            else
                Macro.fishLostCount += 1
        }
        StopMacroCycle("DONE")
    }
}

HoldMouse() {
    global Macro, MAIN

    if (Macro.isHolding)
        return

    delay := MAIN["fishing_action_delay_ms"] + 0
    if (Macro.phase = "FISHING" && delay > 0 && Macro.lastActionAt && (A_TickCount - Macro.lastActionAt) < delay)
        return

    Send("{LButton down}")
    Macro.isHolding := true
    Macro.lastActionAt := A_TickCount
}

ReleaseMouse(force := false) {
    global Macro, MAIN

    if (!Macro.isHolding)
        return

    delay := MAIN["fishing_action_delay_ms"] + 0
    if (!force && Macro.phase = "FISHING" && delay > 0 && Macro.lastActionAt && (A_TickCount - Macro.lastActionAt) < delay)
        return

    Send("{LButton up}")
    Macro.isHolding := false
    Macro.lastActionAt := A_TickCount
}

ReadFramePosition(frameAddr) {
    global OFFSETS

    base := OFFSETS["FramePositionX"] + 0
    scaleX := ReadFloat(frameAddr + base + 0x0)
    offsetX := ReadInt(frameAddr + base + 0x4)

    return {
        X: scaleX,
        XOffset: offsetX
    }
}

ReadFrameSize(frameAddr) {
    global OFFSETS

    base := OFFSETS["FrameSizeX"] + 0
    scaleX := ReadFloat(frameAddr + base + 0x0)
    offsetX := ReadInt(frameAddr + base + 0x4)

    return {
        X: scaleX,
        XOffset: offsetX
    }
}

GetReelGui() {
    playerGui := FindPlayerGui()
    if (!playerGui)
        return 0

    return FindChildByName(playerGui, "reel")
}

GetTranquilityGui() {
    playerGui := FindPlayerGui()
    if (!playerGui)
        return 0

    return FindChildByName(playerGui, "TranquilityRodRhythmGame")
}

GetTranquilityRoot(gui := 0) {
    gui := gui ? gui : GetTranquilityGui()
    return gui ? FindChildByName(gui, "RhythmGame") : 0
}

GetTranquilityLaneContainer(root := 0) {
    root := root ? root : GetTranquilityRoot()
    return root ? FindChildByName(root, "LaneContainer") : 0
}

GetTranquilityLane(index, container := 0) {
    container := container ? container : GetTranquilityLaneContainer()
    return container ? FindChildByName(container, "Lane" index) : 0
}

GetTranquilityHealthFill(root := 0) {
    root := root ? root : GetTranquilityRoot()
    if (!root)
        return 0

    healthBar := FindChildByName(root, "HealthBar")
    return healthBar ? FindChildByName(healthBar, "Fill") : 0
}

ReadTranquilityProgressPercent(root := 0) {
    fill := GetTranquilityHealthFill(root)
    if (!fill)
        return ""

    return ReadProgressBarPercent(fill)
}

ReadGuiObjectVisible(instanceAddr) {
    global OFFSETS

    if (!instanceAddr)
        return false

    className := ReadClassName(instanceAddr)
    if (className = "TextLabel" && OFFSETS.Has("TextLabelVisible"))
        return ReadByte(instanceAddr + (OFFSETS["TextLabelVisible"] + 0)) ? true : false

    if OFFSETS.Has("FrameVisible")
        return ReadByte(instanceAddr + (OFFSETS["FrameVisible"] + 0)) ? true : false

    return true
}

IsReasonableGuiScale(value) {
    return value > -5.0 && value < 5.0
}

GetTranquilityLaneKey(index, root := 0, lane := 0) {
    static fallbackKeys := Map(1, "A", 2, "S", 3, "D", 4, "F")

    root := root ? root : GetTranquilityRoot()
    label := root ? FindChildByName(root, "KeyLabel" index) : 0
    if (!label && lane)
        label := FindChildByName(lane, "KeyLabel")

    if (label) {
        keyText := Trim(ReadGuiText(label))
        if (StrLen(keyText) = 1)
            return StrUpper(keyText)
    }

    return fallbackKeys.Has(index) ? fallbackKeys[index] : ""
}

IsReelGuiVisible(reelGui := 0) {
    global OFFSETS

    if (!reelGui)
        reelGui := GetReelGui()
    if (!reelGui)
        return false

    if (!OFFSETS.Has("ScreenGuiEnabled"))
        return true

    return ReadByte(reelGui + (OFFSETS["ScreenGuiEnabled"] + 0)) ? true : false
}

GetReelBarContext() {
    global Macro

    reelGui := GetReelGui()
    if (!reelGui) {
        Macro.reelBarAddr := 0
        Macro.fishAddr := 0
        Macro.playerbarAddr := 0
        Macro.progressBarAddr := 0
        return 0
    }

    if (IsCachedAddrValid(Macro.reelBarAddr, "bar") && Macro.fishAddr && Macro.playerbarAddr) {
        return {
            bar: Macro.reelBarAddr,
            fish: Macro.fishAddr,
            playerbar: Macro.playerbarAddr
        }
    }

    Macro.reelBarAddr := 0
    Macro.fishAddr := 0
    Macro.playerbarAddr := 0

    barFrame := FindChildByName(reelGui, "bar")
    if (!barFrame)
        return 0

    fishAddr := FindChildByName(barFrame, "fish")
    playerbarAddr := FindChildByName(barFrame, "playerbar")

    Macro.reelBarAddr := barFrame
    Macro.fishAddr := fishAddr
    Macro.playerbarAddr := playerbarAddr

    return {
        bar: barFrame,
        fish: fishAddr,
        playerbar: playerbarAddr
    }
}

HasActiveFishingContext(ctx := "") {
    if (ctx = "")
        ctx := GetReelBarContext()
    return (ctx && ctx.fish && ctx.playerbar) ? true : false
}

GetReelProgressContext() {
    global Macro

    reelGui := GetReelGui()
    if (!reelGui) {
        Macro.progressBarAddr := 0
        return 0
    }

    if (IsCachedAddrValid(Macro.progressBarAddr, "bar") && IsCachedAddrValid(Macro.reelBarAddr, "bar")) {
        return {
            reel: reelGui,
            controlBar: Macro.reelBarAddr,
            progress: 0,
            progressBar: Macro.progressBarAddr
        }
    }

    Macro.progressBarAddr := 0

    controlBar := IsCachedAddrValid(Macro.reelBarAddr, "bar") ? Macro.reelBarAddr : FindChildByName(reelGui, "bar")
    if (!controlBar)
        return 0

    progressFrame := FindChildByName(controlBar, "progress")
    if (!progressFrame)
        return 0

    progressBar := FindChildByName(progressFrame, "bar")
    if (!progressBar)
        return 0

    Macro.progressBarAddr := progressBar

    return {
        reel: reelGui,
        controlBar: controlBar,
        progress: progressFrame,
        progressBar: progressBar
    }
}

ReadProgressBarPercent(frameAddr) {
    size := ReadFrameSize(frameAddr)
    return Max(0.0, Min(100.0, size.X * 100.0))
}

GetFishingCompletionPercent() {
    ctx := GetReelProgressContext()
    if (!ctx || !ctx.progressBar)
        return ""

    return ReadProgressBarPercent(ctx.progressBar)
}

IsFishingCompletionReached(threshold := 99.7) {
    percent := GetFishingCompletionPercent()
    return (percent != "" && percent >= threshold)
}

IsIndicatorSafe(ctx := "") {
    if (ctx = "")
        ctx := GetReelBarContext()
    if (!ctx || !ctx.playerbar || !ctx.fish)
        return ""

    playerbarPos := ReadFramePosition(ctx.playerbar)
    playerbarSize := ReadFrameSize(ctx.playerbar)
    fishPos := ReadFramePosition(ctx.fish)
    fishSize := ReadFrameSize(ctx.fish)

    fishCenter := fishPos.X + (fishSize.X / 2)

    halfWidth := playerbarSize.X / 2
    safeZoneLeft := playerbarPos.X - halfWidth
    safeZoneRight := playerbarPos.X + halfWidth

    return (fishCenter >= safeZoneLeft && fishCenter <= safeZoneRight)
}

ResolvePowerBarPath() {
    global Macro

    if (IsCachedAddrValid(Macro.powerBarAddr, "bar"))
        return { bar: Macro.powerBarAddr }

    Macro.powerBarAddr := 0

    workspace := GetWorkspaceRoot()
    if (!workspace)
        return { bar: 0 }

    localPlayer := GetLocalPlayer()
    if (!localPlayer)
        return { bar: 0 }

    playerName := ReadInstanceName(localPlayer)
    if (playerName = "" || playerName = "<null>")
        return { bar: 0 }

    character := FindChildByName(workspace, playerName)
    if (!character)
        return { bar: 0 }

    rootPart := FindChildByName(character, "HumanoidRootPart")
    if (!rootPart)
        return { bar: 0 }

    powerGui := FindChildByName(rootPart, "power")
    if (!powerGui)
        return { bar: 0 }

    bar := FindDescendantFrameByName(powerGui, "bar")
    if (!bar)
        return { bar: 0 }

    Macro.powerBarAddr := bar
    return { bar: bar }
}

ReadPowerBarPercent(instanceAddr) {
    global OFFSETS

    ; Power bar scale is read from the Y axis (0x8) because the in-game
    ; BillboardGui power bar grows vertically. scaleX would be wrong here.
    base := OFFSETS["FrameSizeX"] + 0
    scaleY := ReadFloat(instanceAddr + base + 0x8)
    percent := scaleY * 100.0

    return Max(0.0, Min(100.0, percent))
}

FindDescendantFrameByName(rootAddr, targetName) {
    queue := [rootAddr]
    index := 1

    while (index <= queue.Length) {
        current := queue[index]
        index += 1

        if (ReadInstanceName(current) = targetName && ReadClassName(current) = "Frame")
            return current

        for childPtr in ReadChildren(current)
            queue.Push(childPtr)
    }

    return 0
}

ReadNotePosition(frameAddr) {
    global OFFSETS
    base := OFFSETS["FramePositionX"] + 0
    return {
        sx: ReadFloat(frameAddr + base + 0x0),
        ox: ReadInt(frameAddr + base + 0x4),
        sy: ReadFloat(frameAddr + base + 0x8),
        oy: ReadInt(frameAddr + base + 0xC)
    }
}

GetNoteContainer() {
    global Macro

    if (IsCachedAddrValid(Macro.reelBarAddr, "bar"))
        return FindChildByName(Macro.reelBarAddr, "noteContainer")

    ctx := GetReelBarContext()
    if (!ctx || !ctx.bar)
        return 0
    return FindChildByName(ctx.bar, "noteContainer")
}

; Returns the nearest airborne note to the bar's current X, or "" if none.
; Notes are always the priority — fish tracking only happens during gaps
; between notes. Picking the nearest one keeps the bar from abandoning a
; close note for a more distant one.
GetActiveNoteTarget(playerbarX) {
    noteContainer := GetNoteContainer()
    if (!noteContainer)
        return ""

    best := ""
    bestDist := 99999.0

    for noteName in ["note1", "note2", "note3", "note4"] {
        noteAddr := FindChildByName(noteContainer, noteName)
        if (!noteAddr)
            continue
        pos := ReadNotePosition(noteAddr)
        if (pos.sy > 0.55 || pos.sy < -30)
            continue

        dist := Abs(pos.sx - playerbarX)
        if (dist < bestDist) {
            bestDist := dist
            best := { sx: pos.sx, sy: pos.sy }
        }
    }

    return best
}

class FishingController {
    Reset() {
        for _, propName in ["lastPlayerbarPos", "lastFishPos", "pwmAccumulator"] {
            if (this.HasOwnProp(propName))
                this.DeleteProp(propName)
        }
    }

    Update(ctx := "") {
        if (ctx = "")
            ctx := GetReelBarContext()

        isSafe := IsIndicatorSafe(ctx)
        if (isSafe = "") {
            this.Release()
            return
        }

        fishPos := this.GetFishPosition(ctx)
        playerbarPos := this.GetPlayerbarPosition(ctx)

        if (fishPos = "" || playerbarPos = "")
            return

        if (!this.HasOwnProp("lastPlayerbarPos"))
            this.lastPlayerbarPos := playerbarPos

        if (!this.HasOwnProp("lastFishPos"))
            this.lastFishPos := fishPos

        playerbarVelocity := playerbarPos - this.lastPlayerbarPos
        this.lastPlayerbarPos := playerbarPos

        fishVelocity := fishPos - this.lastFishPos
        this.lastFishPos := fishPos

        error := fishPos - playerbarPos

        edgeBoundary := MAIN["edge_boundary"]
        if (playerbarPos < edgeBoundary) {
            this.Hold()
            return
        }
        if (playerbarPos > 1 - edgeBoundary) {
            this.Release()
            return
        }

        predictionScale := MAIN["prediction_strength"]
        predicted := playerbarPos + (playerbarVelocity * predictionScale)
        predictedError := fishPos - predicted

        hardFixThreshold := 0.01
        sameSideAfterPrediction := (error * predictedError) > 0

        approachingTarget := (error * playerbarVelocity) > 0
        remainingDistance := Max(0.0, Abs(error) - hardFixThreshold)

        ; full stop fixing and start bleeding speed early
        brakeLookahead := Abs(playerbarVelocity) * 8
        needsPreSlow := approachingTarget && (brakeLookahead >= remainingDistance)

        ; hard fix only when far enough and not yet in the braking zone
        if (Abs(error) > hardFixThreshold && sameSideAfterPrediction && !needsPreSlow) {
            if (error > 0)
                this.Hold()
            else
                this.Release()
            return
        }

        neutralDuty := MAIN["neutral_duty_cycle"]

        if (needsPreSlow && brakeLookahead > 0) {
            brakeUrgency := 1.0 - Min(1.0, remainingDistance / brakeLookahead)

            if (error > 0) {
                targetDuty := neutralDuty * (1.0 - brakeUrgency)
            } else {
                targetDuty := neutralDuty + ((1.0 - neutralDuty) * brakeUrgency)
            }
        } else {
            ; Normal pwm balancing // fine tracking
            kP := MAIN["proportional_gain"]
            kD := MAIN["derivative_gain"]
            kV := MAIN["velocity_damping"]

            adjustment := (kP * error) + (kD * fishVelocity) - (kV * playerbarVelocity)
            targetDuty := Max(0.0, Min(1.0, neutralDuty + adjustment))
        }

        if (!this.HasOwnProp("pwmAccumulator"))
            this.pwmAccumulator := 0.0

        this.pwmAccumulator += targetDuty
        if (this.pwmAccumulator >= 1.0) {
            this.pwmAccumulator -= 1.0
            this.Hold()
        } else {
            this.Release()
        }
    }

    GetFishPosition(ctx := "") {
        if (ctx = "")
            ctx := GetReelBarContext()
        if (!ctx || !ctx.fish)
            return ""

        fishPos := ReadFramePosition(ctx.fish)
        fishSize := ReadFrameSize(ctx.fish)
        return fishPos.X + (fishSize.X / 2)
    }

    GetPlayerbarPosition(ctx := "") {
        if (ctx = "")
            ctx := GetReelBarContext()
        if (!ctx || !ctx.playerbar)
            return ""

        playerbarPos := ReadFramePosition(ctx.playerbar)
        return playerbarPos.X
    }

    Hold() {
        HoldMouse()
    }

    Release() {
        ReleaseMouse()
    }
}

class PinionController extends FishingController {
    static NOTE_MODE_ENTRY := 27.0
    static NOTE_MODE_EXIT  := 20.0

    pinionNoteModeActive := false

    Reset() {
        super.Reset()
        this.pinionNoteModeActive := false
    }

    GetFishPosition(ctx := "") {
        if (ctx = "")
            ctx := GetReelBarContext()
        fishX := super.GetFishPosition(ctx)
        playerbarX := this.GetPlayerbarPosition(ctx)

        if (playerbarX = "")
            return fishX

        progress := GetFishingCompletionPercent()

        ; Hysteresis gate: must reach entry threshold to start note mode,
        ; stays active until progress falls below the lower exit threshold.
        if (progress = "") {
            this.pinionNoteModeActive := false
            return fishX
        }

        if (this.pinionNoteModeActive) {
            if (progress < PinionController.NOTE_MODE_EXIT) {
                this.pinionNoteModeActive := false
                return fishX
            }
        } else {
            if (progress < PinionController.NOTE_MODE_ENTRY)
                return fishX
            this.pinionNoteModeActive := true
        }

        note := GetActiveNoteTarget(playerbarX)
        if (note = "")
            return fishX

        t := Min(1.0, (progress - PinionController.NOTE_MODE_ENTRY) / 28.0)
        maxReach := 0.1 + (t * 0.9)
        if (Abs(note.sx - playerbarX) > maxReach)
            return fishX

        return note.sx
    }
}

class TranquilityController {
    static HIT_Y_MIN := 0.78
    static HIT_Y_MAX := 0.90
    static KEY_COOLDOWN_MS := 30

    __New() {
        this.hitNotes := Map()
        this.lastKeySentAt := Map()
    }

    Reset() {
        ReleaseMouse(true)
        this.hitNotes := Map()
        this.lastKeySentAt := Map()
    }

    Update(ctx := "") {
        ReleaseMouse(true)

        root := GetTranquilityRoot()
        if (!root)
            return

        container := GetTranquilityLaneContainer(root)
        if (!container)
            return

        seenNotes := Map()

        Loop 4 {
            lane := GetTranquilityLane(A_Index, container)
            if (!lane || !ReadGuiObjectVisible(lane))
                continue

            key := GetTranquilityLaneKey(A_Index, root, lane)
            if (key = "")
                continue

            for noteAddr in ReadChildren(lane) {
                if (ReadInstanceName(noteAddr) != "Note" || ReadClassName(noteAddr) != "ImageLabel")
                    continue

                seenNotes[noteAddr] := true
                if (this.hitNotes.Has(noteAddr) || !ReadGuiObjectVisible(noteAddr))
                    continue

                pos := ReadNotePosition(noteAddr)
                if (!IsReasonableGuiScale(pos.sy))
                    continue

                if (pos.sy >= TranquilityController.HIT_Y_MIN && pos.sy <= TranquilityController.HIT_Y_MAX)
                    this.PressLaneKey(key, noteAddr)
            }
        }

        staleNotes := []
        for noteAddr, _ in this.hitNotes {
            if (!seenNotes.Has(noteAddr))
                staleNotes.Push(noteAddr)
        }

        for _, noteAddr in staleNotes
            this.hitNotes.Delete(noteAddr)
    }

    PressLaneKey(key, noteAddr) {
        now := A_TickCount
        lastSentAt := this.lastKeySentAt.Has(key) ? this.lastKeySentAt[key] : 0
        if (lastSentAt && (now - lastSentAt) < TranquilityController.KEY_COOLDOWN_MS)
            return false

        SendInput("{" key "}")
        this.lastKeySentAt[key] := now
        this.hitNotes[noteAddr] := now
        return true
    }
}
